package com.rhwayfun.springboot.quickstart.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.rhwayfun.springboot.quickstart.filter.SessionFilter;
/**
 * 过滤器设置到配置中
 * @author 25772
 *
 */
@Configuration
public class WebComponent2Config {
    @Bean
    public FilterRegistrationBean someFilterRegistration1() {
        //新建过滤器注册类
        FilterRegistrationBean registration = new FilterRegistrationBean();
        // 添加我们写好的过滤器
        registration.setFilter(new SessionFilter());
        // 设置过滤器的URL模式,过滤所有的URL
        registration.addUrlPatterns("/*");
        System.err.println(registration);
        return registration;
    }

}