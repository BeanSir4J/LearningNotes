package com.rhwayfun.springboot.quickstart.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by chubin on 2017/9/10.
 */
@Controller
public class DemoController {

/*
    @GetMapping({"/","/index","/beetl"})
    public String beetl(Model model){
        model.addAttribute("beetl","测试一下通过模板引擎传递参数！");
        return "index.html";
    }
*/
    @RequestMapping("index")
    @ResponseBody
    public String index(Model model){
    	return "123";
    }
    
    @RequestMapping("index2")
    @ResponseBody
    public String index2(Model model){
    	return "234";
    }
    
    
}
