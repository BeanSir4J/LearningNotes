package com.rhwayfun.springboot.quickstart.annotation;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

public class MyInfoUtils {

	
	public static void getMyInfoMethod(Class<?> clazz){
		String name="我的名字是:";
		String age="我的年龄是:";
		Field[] declaredFields = clazz.getDeclaredFields();
		for (Field field : declaredFields) {
			if(field.isAnnotationPresent(MyInfo.class)){
				MyInfo annotation = field.getAnnotation(MyInfo.class);
				System.err.println(annotation.name());
				System.err.println(annotation.age());
			}
		}
	}
	
	public static void main(String[] args) {
		getMyInfoMethod(MyEntity.class);
	}
}
