package com.rhwayfun.springboot.quickstart.annotation;

public class MyEntity {
	@MyInfo(name="BeanSir4J")
	private String name;
	@MyInfo(age="123")
	private String age;
	
}
