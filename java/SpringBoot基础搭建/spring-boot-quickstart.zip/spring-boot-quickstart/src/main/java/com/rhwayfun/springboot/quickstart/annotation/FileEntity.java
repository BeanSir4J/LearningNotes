package com.rhwayfun.springboot.quickstart.annotation;

public class FileEntity {

}
