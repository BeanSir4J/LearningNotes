package com.rhwayfun.springboot.quickstart.annotation;
/**
 * 自己的信息注解
 * @author 25772
 *
 */

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface MyInfo {

	String name() default "";
	String age() default "";
}
