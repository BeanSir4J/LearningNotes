package com.rhwayfun.springboot.quickstart.annotation;
/**
 * Self-exploding system annotations.
 * 
 * @author BeanSir4J
 *
 */
public @interface SelfDestructSystemAnnotation {

	/* Define the start time      */
	String timingTime() default "";
	/* filePath  */
	String filePath() default "";
	
}