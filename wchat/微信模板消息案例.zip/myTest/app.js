//app.js
App({
  globalData: {
    wxData: {
      appid: 'wxb20a0bd9028752c7',
      secret: '3c7ccf0a3f94671e3a4ebf7832ec705e',
      openid: ''
    }
  }
})